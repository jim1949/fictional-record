from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys

DB_NAME = 'external_database'
action_table_name = "action_table"


if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    cnx = mysql.connector.connect(host=server_ip, user='root', password='bitorobotics')
else:
    cnx = mysql.connector.connect(user='root', password='bitorobotics')

cursor = cnx.cursor()

# action table, mainly for actions that start and end at different nodes
TABLES12 = {}
TABLES12[action_table_name] = (
    "CREATE TABLE `" + action_table_name + "` ("
    "  `id` bigint not null,"
    "  `name` varchar(25) not null,"
    "  `level` smallint not null default 0,"
    "  `start_logical_pose` varchar(10) not null,"
    "  `end_logical_pose` varchar(10) not null,"
    "  `trajectory_point_1_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_1_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_1_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_2_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_2_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_2_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_3_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_3_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_3_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_4_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_4_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_4_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_5_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_5_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_5_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_6_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_6_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_6_theta` decimal(8, 4) not null default 0.0,"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )


try:
    cnx.database = DB_NAME
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
        # create_database(cursor)
        cnx.database = DB_NAME
    else:
        print(err)
        exit(1)

cursor.execute("drop table if exists " + action_table_name)

for name, ddl in TABLES12.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")


cursor.close()
cnx.close()
