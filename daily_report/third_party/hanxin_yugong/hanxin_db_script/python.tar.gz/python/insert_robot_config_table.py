'''
 * All Rights Reserved
 * BITO Robotics, Inc.
 *
 * Authors: Zhongqiang Ren,
 * Create Date: 2018-07
 * Last Edit Date: 2018-07
'''

from __future__ import print_function

# Import Python libraries
import time
import sys

# Import SQL related libraries
import mysql.connector
from mysql.connector import errorcode

DB_NAME = 'external_database'

# +-----------------+--------------+------+-----+---------+----------------+
# | Field           | Type         | Null | Key | Default | Extra          |
# +-----------------+--------------+------+-----+---------+----------------+
# | id              | bigint(20)   | NO   | PRI | NULL    | auto_increment |
# | serial          | varchar(25)  | NO   |     | NULL    |                |
# | battery_voltage | decimal(8,4) | NO   |     | 0.0000  |                |
# | payload         | decimal(8,4) | NO   |     | 0.0000  |                |
# | trajectory_mode | smallint(6)  | NO   |     | 0       |                |
# | footprint_c1_x  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c1_y  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c1_r  | decimal(8,4) | NO   |     | -1.0000 |                |
# | footprint_c2_x  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c2_y  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c2_r  | decimal(8,4) | NO   |     | -1.0000 |                |
# | footprint_c3_x  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c3_y  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c3_r  | decimal(8,4) | NO   |     | -1.0000 |                |
# | footprint_c4_x  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c4_y  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c4_r  | decimal(8,4) | NO   |     | -1.0000 |                |
# | footprint_c5_x  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c5_y  | decimal(8,4) | NO   |     | 0.0000  |                |
# | footprint_c5_r  | decimal(8,4) | NO   |     | -1.0000 |                |
# | type            | varchar(25)  | NO   |     | NULL    |                |
# +-----------------+--------------+------+-----+---------+----------------+


def robot_config_data():
  # data = \
  #   [ ("yg00sim018042309001n00", 48.0, 1000.00, 1, 0.4, 0, 0.8, 0, 0, 0.8, -0.4, 0, 0.8, 0, 0, -1, 0, 0, -1, ""),
  #     ("yg00sim018042309002n00", 48.0, 1000.00, 1, 0.4, 0, 0.8, 0, 0, 0.8, -0.4, 0, 0.8, 0, 0, -1, 0, 0, -1, ""),
  #     ("yg00sim01804230900xn00", 24.0, 1000.00, 0, -0.22, 0, 0.34, 0.22, 0, 0.34, 1.33, 0, 0.425, 0.66, 0, 0.34, 0, 0, -1, ""),
  #     ("yg00rvz017120415001n00", 24.0, 1000.00, 0, -0.22, 0, 0.34, 0.22, 0, 0.34, 1.33, 0, 0.425, 0.66, 0, 0.34, 0, 0, -1, "blueant"),
  #     ("yg00a10018022817000n00", 24.0, 1000.00, 0, 0.4, 0, 0.8, -0.4, 0, 0.8, 0, 0, 0.8, 0, 0, -1, 0, 0, -1, "blueant"),
  #     ("yg00a00017070814000n00", 24.0, 1000.00, 0, 0.4, 0, 0.8, -0.4, 0, 0.8, 0, 0, 0.8, 0, 0, -1, 0, 0, -1, "blueant"),
  #     ("yg00a00017120415000n00", 24.0, 1000.00, 0, 0.4, 0, 0.8, -0.4, 0, 0.8, 0, 0, 0.8, 0, 0, -1, 0, 0, -1, "blueant"),
  #     ("yg00b10018080410000n00", 24.0, 1000.00, 0, 0.4, 0, 0.8, -0.4, 0, 0.8, 0, 0, 0.8, 0, 0, -1, 0, 0, -1, "blueant"),
  #     ("yg00b10018042310000n00", 24.0, 1000.00, 0, 0.4, 0, 0.8, -0.4, 0, 0.8, 0, 0, 0.8, 0, 0, -1, 0, 0, -1, "blueant"),
  #     ("yg00a00017071020003n00", 24.0, 1000.00, 0, 0.4, 0, 0.8, -0.4, 0, 0.8, 0, 0, 0.8, 0, 0, -1, 0, 0, -1, "blueant"),
  #     ("yg00b10018042312000n00", 24.0, 1000.00, 0, 0.4, 0, 0.8, -0.4, 0, 0.8, 0, 0, 0.8, 0, 0, -1, 0, 0, -1, "blueant"),
  #     ("yg00a20018112111000n00", 24.0, 1000.00, 0, 0.4, 0, 0.8, -0.4, 0, 0.8, 0, 0, 0.8, 0, 0, -1, 0, 0, -1, "blueant"),
  #     ("yg00a00017120413000n00", 24.0, 1000.00, 0, 0.4, 0, 0.8, -0.4, 0, 0.8, 0, 0, 0.8, 0, 0, -1, 0, 0, -1, "blueant"),
  #     ("yg00rvz017120415002n00", 24.0, 1000.00, 0, -0.22, 0, 0.34, 0.22, 0, 0.34, 1.33, 0, 0.425, 0.66, 0, 0.34, 0, 0, -1, "forklift"),
  #     ("yg00sim018042309011n00", 24.0, 1000.00, 0, -0.22, 0, 0.34, 0.22, 0, 0.34, 1.33, 0, 0.425, 0.66, 0, 0.34, 0, 0, -1, "blueant"),
  #     ("yg00b10019022611000n00", 24.0, 1000.00, 0, -0.22, 0, 0.34, 0.22, 0, 0.34, 1.33, 0, 0.425, 0.66, 0, 0.34, 0, 0, -1, "dji_robot"),
  #     ("yg00b10018120710000n00", 24.0, 1000.00, 0, -0.22, 0, 0.34, 0.22, 0, 0.34, 1.33, 0, 0.425, 0.66, 0, 0.34, 0, 0, -1, "forklift"),
  #     ("yg00b10019011810000n00", 24.0, 1000.00, 0, -0.22, 0, 0.34, 0.22, 0, 0.34, 1.33, 0, 0.425, 0.66, 0, 0.34, 0, 0, -1, "forklift")	]
  # return data
  #GPM
  data = \
    [ ("yg00sim018042309000n00", 48.0, 1000.00, 1, 0.36575, 0, 0.44, -0.36575, 0, 0.44, 0, 0, -1, 0, 0, -1, 0, 0, -1, "GPM"),
      ("yg00sim018042309000n01", 48.0, 1000.00, 1, 0.36575, 0, 0.44, -0.36575, 0, 0.44, 0, 0, -1, 0, 0, -1, 0, 0, -1, "GPM"),
      ("yg00sim018042309000n02", 48.0, 1000.00, 1, 0.36575, 0, 0.44, -0.36575, 0, 0.44, 0, 0, -1, 0, 0, -1, 0, 0, -1, "GPM"),
      ("yg00sim018042309000n03", 48.0, 1000.00, 1, 0.36575, 0, 0.44, -0.36575, 0, 0.44, 0, 0, -1, 0, 0, -1, 0, 0, -1, "GPM") ]
  return data

def main_func():
  if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    config = {'host':server_ip, 'user':'root', \
              'password':'bitorobotics', 'database':DB_NAME}
  else:
    config = {'user':'root', 'password':'bitorobotics', \
              'database':DB_NAME}

  try:
      cnx = mysql.connector.connect(**config)
  except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
      print("Database {} does not exist". format(DB_NAME))
    else:
      print(err)

  cursor = cnx.cursor()
  
  # clear tables
  cursor.execute("DELETE FROM robot_config_table")
  cnx.commit()

  query_insert_robot_config = ("INSERT INTO robot_config_table " +\
                          "(serial, battery_voltage, payload, trajectory_mode," +\
                          "footprint_c1_x, footprint_c1_y, footprint_c1_r, " +\
                          "footprint_c2_x, footprint_c2_y, footprint_c2_r, " +\
                          "footprint_c3_x, footprint_c3_y, footprint_c3_r, " +\
                          "footprint_c4_x, footprint_c4_y, footprint_c4_r, " +\
                          "footprint_c5_x, footprint_c5_y, footprint_c5_r, " +\
                          "type" +\
                          ") VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,"+\
                          "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)")

  robot_data = robot_config_data()
  for item in robot_data:
    cursor.execute(query_insert_robot_config, item)
  cnx.commit()

  cursor.close()
  cnx.close()
  return

if __name__ == "__main__":
  print(" Program Begin ...")
  main_func()
  print(" Program End ...")
