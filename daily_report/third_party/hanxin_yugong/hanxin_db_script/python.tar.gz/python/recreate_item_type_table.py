from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys

DB_NAME = 'external_database'


item_type_table_name = "item_type_table"


if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    cnx = mysql.connector.connect(host=server_ip, user='root', password='bitorobotics')
else:
    cnx = mysql.connector.connect(user='root', password='bitorobotics')

cursor = cnx.cursor()


# item type database
TABLES6 = {}
TABLES6[item_type_table_name] = (
    "CREATE TABLE `" + item_type_table_name + "` ("
    "  `id` bigint not null auto_increment,"
    "  `type` bigint not null default 0," # must be unique
    "  `name` varchar(25) not null,"
    "  `length` decimal(8, 4) not null default 0.0,"
    "  `width` decimal(8, 4) not null default 0.0,"
    "  `height` decimal(8, 4) not null default 0.0,"
    "  `weight` decimal(8, 4) not null default 0.0,"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )



try:
    cnx.database = DB_NAME
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
        # create_database(cursor)
        cnx.database = DB_NAME
    else:
        print(err)
        exit(1)

cursor.execute("drop table if exists "+item_type_table_name)

for name, ddl in TABLES6.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

cursor.close()
cnx.close()
