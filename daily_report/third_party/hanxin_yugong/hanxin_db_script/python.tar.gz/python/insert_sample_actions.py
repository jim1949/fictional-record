# from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys


def action_table_data(): 
  action_table_data = \
    [("10", "Special Pick Up", '1', "P1S", "P1E"),
     ("11", "Special Pick Up2", '1', "B1", "A2"),
    ]
  return action_table_data

def main_func():
  cnx = mysql.connector.connect(user='root', password="bitorobotics", 
    host="localhost", database="external_database")
  cursor = cnx.cursor()
  
  # clear tables
  cursor.execute("delete from action_table")
  cnx.commit()

  add_action_info = ("INSERT INTO action_table "
               "(id, name, level, start_logical_pose, end_logical_pose) "
               "VALUES (%s, %s, %s, %s, %s)")
  action_data = action_table_data()
  for action in action_data:
    cursor.execute(add_action_info, action)
  cnx.commit()

  cnx.close()
  return

if __name__ == "__main__":
  print " Program Begin ..."
  main_func()
  print " Program End ..."
