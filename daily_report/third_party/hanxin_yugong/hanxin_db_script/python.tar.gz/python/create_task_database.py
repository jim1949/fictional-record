from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys

DB_NAME = 'task_database'

# TODO: allow multiple task table

def create_database(cursor):
    try:
        cursor.execute(
            "DROP DATABASE IF EXISTS {} ".format(DB_NAME))
    except mysql.connector.Error as err:
        print("Failed to drop database: {}".format(err))
    print("after drop")
    try:
        cursor.execute(
            "CREATE DATABASE {} DEFAULT CHARACTER SET 'utf8'".format(DB_NAME))
    except mysql.connector.Error as err:
        print("Failed creating database: {}".format(err))
        exit(1)


TABLES = {}
TABLES['task_database'] = (
    "CREATE TABLE `task_table` ("
    "  `id` bigint unsigned not null auto_increment,"
    "  `start` varchar(10) not null,"
    "  `goal` varchar(10) not null,"
    "  `start_action` smallint not null,"
    "  `goal_action` smallint not null,"
    "  `item_size_length` decimal(8, 4) not null default 0.0,"
    "  `item_size_width` decimal(8, 4) not null default 0.0,"
    "  `item_size_height` decimal(8, 4) not null default 0.0,"
    "  `item_weight` decimal(8, 4) not null default 0.0,"
    "  `priority` int not null default 10,"
    "  `status` int not null default 0,"
    "  `estimated_finish_timestamp` timestamp,"
    "  `preassignment` varchar(30) not null,"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB")


if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    cnx = mysql.connector.connect(host=server_ip, user='root', password='bitorobotics')
else:
    cnx = mysql.connector.connect(user='root', password='bitorobotics')

cursor = cnx.cursor()

create_database(cursor)

try:
    cnx.database = DB_NAME
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
        create_database(cursor)
        cnx.database = DB_NAME
    else:
        print(err)
        exit(1)

for name, ddl in TABLES.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

cursor.close()
cnx.close()
