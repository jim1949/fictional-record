from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys

DB_NAME = 'external_database'


logical_pose_table_3d_name = "logical_pose_table_3d"


if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    cnx = mysql.connector.connect(host=server_ip, user='root', password='bitorobotics')
else:
    cnx = mysql.connector.connect(user='root', password='bitorobotics')

cursor = cnx.cursor()


# logical pose table
TABLES = {}
TABLES[logical_pose_table_3d_name] = (
    "CREATE TABLE `" + logical_pose_table_3d_name + "` ("
    "  `id` bigint not null default 0,"
    "  `logical_pose` varchar(10) not null,"
    "  `real_pose_x` decimal(10, 4) not null,"
    "  `real_pose_y` decimal(10, 4) not null,"
    "  `real_pose_z` decimal(10, 4) not null,"
    "  `real_pose_qx` decimal(10, 4) not null,"
    "  `real_pose_qy` decimal(10, 4) not null,"
    "  `real_pose_qz` decimal(10, 4) not null,"
    "  `real_pose_qw` decimal(10, 4) not null,"
    "  `real_pose_id` bigint not null,"
    "  `info` varchar(50) not null default '',"
    "  `status` int not null default 0,"
    "  `region_code` varchar(20) not null default '',"
    "  `start_action_type` int not null default 0,"
    "  `goal_action_type` int not null default 0,"
    "  PRIMARY KEY (`logical_pose`)"
    ") ENGINE=InnoDB"
    )


try:
    cnx.database = DB_NAME
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
        # create_database(cursor)
        cnx.database = DB_NAME
    else:
        print(err)
        exit(1)

cursor.execute("drop table if exists "+logical_pose_table_3d_name)

for name, ddl in TABLES.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

cursor.close()
cnx.close()
