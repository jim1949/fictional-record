# from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys


def home_pose_table_data():
  home_pose_table_data = \
    [("H1", 0, 0, 0, 47),
     ("H2", 10, 0, 0,67),
     ("H3", 8, 3, 0, 1787)]
  return home_pose_table_data

def main_func():
  cnx = mysql.connector.connect(user='root', password="bitorobotics", 
    host="localhost", database="external_database")
  cursor = cnx.cursor()
  
  # clear tables
  cursor.execute("delete from home_pose_table")
  cnx.commit()

  add_home_pose = ("INSERT INTO home_pose_table "
               "(serial, home_pose_x, home_pose_y, \
                 home_pose_theta, home_pose_id) "
               "VALUES (%s, %s, %s, %s, %s)")
  home_poses = home_pose_table_data()
  for hp in home_poses:
    cursor.execute(add_home_pose, hp)
  cnx.commit()

  cnx.close()
  return

if __name__ == "__main__":
  print " Program Begin ..."
  main_func()
  print " Program End ..."
