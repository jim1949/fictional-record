'''
 * All Rights Reserved
 * BITO Robotics, Inc.
 *
 * Authors: Zhongqiang Ren,
 * Create Date: 2018-07
 * Last Edit Date: 2018-07
'''

from __future__ import print_function

# Import Python libraries
import time
import sys

# Import SQL related libraries
import mysql.connector
from mysql.connector import errorcode

DB_NAME = 'external_database'

def logical_table_data():
  data = \
    [ ("A", 10, 10, 0.00, 1),
      ("B", 15, 10, 0.00, 2),
      ("C", 20, 10, 0.00, 3),
      ("D", 25, 10, 0.00, 4),
      ("E", 10, 15, 0.00, 5),
      ("F", 15, 15, 0.00, 6),
      ("G", 20, 15, 0.00, 7),
      ("H", 25, 15, 0.00, 8),
      ("I", 10, 20, 0.00, 9),
      ("J", 15, 20, 0.00, 10),
      ("K", 20, 20, 0.00, 11),
      ("L", 25, 20, 0.00, 12)]
  return data

def task_table_data():
  data = \
    [("A", "K", 0, 0),
     ("B", "I", 0, 0),
     ("C", "L", 0, 0),
     ("D", "H", 0, 0)]
  return data

def main_func():
  if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    config = {'host':server_ip, 'user':'root', \
              'password':'bitorobotics', 'database':DB_NAME}
  else:
    config = {'user':'root', 'password':'bitorobotics', \
              'database':DB_NAME}

  try:
      cnx = mysql.connector.connect(**config)
  except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
      print("Database {} does not exist". format(DB_NAME))
    else:
      print(err)

  cursor = cnx.cursor()
  
  # clear tables
  cursor.execute("DELETE FROM task_table")
  cursor.execute("DELETE FROM logical_pose_table")
  cnx.commit()

  query_insert_logical = ("INSERT INTO logical_pose_table " +\
                          "(logical_pose, real_pose_x, real_pose_y, " +\
                          "real_pose_theta, real_pose_id) " +\
                          "VALUES (%s, %s, %s, %s, %s)")

  logical_data = logical_table_data()
  for item in logical_data:
    cursor.execute(query_insert_logical, item)
  cnx.commit()

  query_insert_task = ("INSERT INTO task_table " +\
                              "(start, goal, start_action, goal_action)" +\
                              "VALUES (%s, %s, %s, %s)")

  task_data = task_table_data()
  for item in task_data:
    cursor.execute(query_insert_task, item)
  cnx.commit()

  cursor.close()
  cnx.close()
  return

if __name__ == "__main__":
  print(" Program Begin ...")
  main_func()
  print(" Program End ...")
