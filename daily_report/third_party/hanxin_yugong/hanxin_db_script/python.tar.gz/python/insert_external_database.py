# from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys


def logical_pose_table_data():
  data_logical_pose_table = \
    [("A1", 0, 0, 0, 0),
     ("A2", 2, 0, 0, 1),
     ("A3", 4, 0, 0, 2),
     ("B1", 0, 2, 3.14, 8),
     ("B2", 2, 2, 3.14, 6),
     ("B3", 4, 2, 3.14, 4),
     ("C1", 0, 4, 3.14, 15),
     ("C2", 2, 4, 3.14, 13),
     ("C3", 4, 4, 3.14, 11)]
  return data_logical_pose_table

def task_table_data():
  task_table_data = \
    [("B3", "B1", 0, 0, 'yg00a00017071020003n00'),
     ("C3", "C1", 0, 0, 'yg00a00017071020002n00'),
     ("A1", "A3", 0, 0, 'yg00a00017071020003n00'),
     ("C3", "C1", 0, 0, 'yg00a00017071020002n00')]
     # ("A1", "A2", 2, 1)]
  return task_table_data

def home_pose_table_data():
  home_pose_table_data = \
    [("yg00a00017071020001n00", 0, 0, 0.00, 1)
    #,
    # ("yghh", 7, 5, 0.00)
    ]
  return home_pose_table_data

def main_func():
  cnx = mysql.connector.connect(user='root', password="bitorobotics", 
    host="localhost", database="external_database")
  cursor = cnx.cursor()
  
  # clear tables
  cursor.execute("delete from logical_pose_table_0")
  cursor.execute("delete from task_table")
  cursor.execute("delete from home_pose_table")
  cnx.commit()

  add_logical_pose = ("INSERT INTO logical_pose_table_0 "
               "(logical_pose, real_pose_x, real_pose_y, \
                 real_pose_theta, real_pose_id) "
               "VALUES (%s, %s, %s, %s, %s)")
  logical_poses = logical_pose_table_data()
  for lp in logical_poses:
    cursor.execute(add_logical_pose, lp)
  cnx.commit()

  add_task = ("INSERT INTO task_table "
              "(start, goal, start_action, goal_action, preassignment) "
              "VALUES (%s, %s, %s, %s, %s)")
  tasks = task_table_data()
  for ta in tasks:
    cursor.execute(add_task, ta)
  cnx.commit()

  add_home_pose = ("INSERT INTO home_pose_table "
              "(serial, home_pose_x, home_pose_y, \
                home_pose_theta, home_pose_id) "
              "VALUES (%s, %s, %s, %s, %s)")
  home_poses = home_pose_table_data()
  for home in home_poses:
    cursor.execute(add_home_pose, home)
  cnx.commit()

  cnx.close()
  return

if __name__ == "__main__":
  print " Program Begin ..."
  main_func()
  print " Program End ..."
