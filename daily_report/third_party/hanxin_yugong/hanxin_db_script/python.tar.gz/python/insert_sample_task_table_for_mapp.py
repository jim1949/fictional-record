'''
 * All Rights Reserved
 * BITO Robotics, Inc.
 *
 * Authors: Zhongqiang Ren,
 * Create Date: 2018-07
 * Last Edit Date: 2018-07
'''

from __future__ import print_function

# Import Python libraries
import time
import sys

# Import SQL related libraries
import mysql.connector
from mysql.connector import errorcode

DB_NAME = 'external_database'

def task_table_data():
  # data = \
  #   [("94", "17", 0, 0, "yg00sim018042309001n00"),
  #    ("123", "275", 0, 0, "yg00sim018042309002n00"),
  #    ("59", "175", 0, 0, "yg00sim018042309003n00"),
  #    ("267", "261", 0, 0, "yg00sim018042309004n00"),
  #    ("113", "129", 0, 0, "yg00sim018042309005n00"),
  #    ("184", "19", 0, 0, "yg00sim018042309006n00"),
  #    ("175", "17", 0, 0, "yg00sim018042309001n00"),
  #    ("269", "275", 0, 0, "yg00sim018042309002n00"),
  #    ("264", "175", 0, 0, "yg00sim018042309003n00"),
  #    ("267", "261", 0, 0, "yg00sim018042309004n00"),
  #    ("113", "129", 0, 0, "yg00sim018042309005n00"),
  #    ("184", "19", 0, 0, "yg00sim018042309006n00"),
  #    ("155", "17", 0, 0, "yg00sim018042309001n00"),
  #    ("212", "275", 0, 0, "yg00sim018042309002n00"),
  #    ("196", "175", 0, 0, "yg00sim018042309003n00"),
  #    ("32", "261", 0, 0, "yg00sim018042309004n00"),
  #    ("21", "129", 0, 0, "yg00sim018042309005n00"),
  #    ("20", "19", 0, 0, "yg00sim018042309006n00")]
  data = \
    [("94", "66", 0, 0, "yg00sim018042309001n00"),
     ("216", "251", 0, 0, "yg00sim018042309002n00"),
     ("220", "127", 0, 0, "yg00sim018042309003n00"),
     ("235", "109", 0, 0, "yg00sim018042309004n00"),
     ("224", "84", 0, 0, "yg00sim018042309005n00"),
     ("118", "96", 0, 0, "yg00sim018042309006n00"),
     ("267", "18", 0, 0, "yg00sim018042309007n00"),
     ("251", "235", 0, 0, "yg00sim018042309008n00"),
     ("219", "97", 0, 0, "yg00sim018042309009n00"),
     ("84", "216", 0, 0, "yg00sim018042309010n00"),
     ("224", "18", 0, 0, "yg00sim018042309011n00"),
     ("18", "118", 0, 0, "yg00sim018042309012n00"),
     # ("113", "129", 0, 0, "yg00sim018042309005n00"),
     # ("184", "19", 0, 0, "yg00sim018042309006n00"),
     # ("64", "67", 0, 0, "yg00sim018042309001n00"),
     # ("269", "38", 0, 0, "yg00sim018042309002n00"),
     # ("21", "132", 0, 0, "yg00sim018042309003n00"),
     # ("59", "182", 0, 0, "yg00sim018042309004n00"),
     # ("113", "129", 0, 0, "yg00sim018042309005n00"),
     # ("184", "19", 0, 0, "yg00sim018042309006n00"),
     # ("186", "17", 0, 0, "yg00sim018042309001n00"),
     # ("266", "211", 0, 0, "yg00sim018042309002n00"),
     # ("166", "65", 0, 0, "yg00sim018042309003n00"),
     # ("28", "32", 0, 0, "yg00sim018042309004n00"),
     # ("21", "129", 0, 0, "yg00sim018042309005n00"),
     # ("20", "19", 0, 0, "yg00sim018042309006n00")
     ]
  # # test data for 5 robots that work
  # data = \
  #   [("94", "66", 0, 0, "yg00sim018042309001n00"),
  #    ("216", "251", 0, 0, "yg00sim018042309002n00"),
  #    ("220", "127", 0, 0, "yg00sim018042309003n00"),
  #    ("235", "109", 0, 0, "yg00sim018042309004n00"),
  #    ("66", "199", 0, 0, "yg00sim018042309005n00"),
  #    ("118", "96", 0, 0, "yg00sim018042309006n00"),
  #    ("267", "18", 0, 0, "yg00sim018042309007n00"),
  #    ("251", "235", 0, 0, "yg00sim018042309008n00"),
  #    ("219", "97", 0, 0, "yg00sim018042309009n00"),
  #    ("84", "216", 0, 0, "yg00sim018042309010n00"),
  #    ("224", "18", 0, 0, "yg00sim018042309011n00"),
  #    ("18", "118", 0, 0, "yg00sim018042309012n00"),
  #    ]
  return data


def main_func():
  if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    config = {'host':server_ip, 'user':'root', \
              'password':'bitorobotics', 'database':DB_NAME}
  else:
    config = {'user':'root', 'password':'bitorobotics', \
              'database':DB_NAME}

  try:
      cnx = mysql.connector.connect(**config)
  except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
      print("Database {} does not exist". format(DB_NAME))
    else:
      print(err)

  cursor = cnx.cursor()
  
  # clear tables
  cursor.execute("DELETE FROM task_table")
  cnx.commit()


  query_insert_task = ("INSERT INTO task_table " +\
                              "(start, goal, start_action, goal_action, preassignment)" +\
                              "VALUES (%s, %s, %s, %s, %s)")

  task_data = task_table_data()
  for item in task_data:
    cursor.execute(query_insert_task, item)
  cnx.commit()

  cursor.close()
  cnx.close()
  return

if __name__ == "__main__":
  print(" Program Begin ...")
  main_func()
  print(" Program End ...")
