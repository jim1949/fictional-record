# from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys


def logical_pose_table_data():
  data_logical_pose_table = \
    [("W1", 4, 1, 1, 0, 0, 0, 1, 1),
     ("W2", 6, 1, 1, 0, 0, 0.707, 0.707, 2),
     ("W3", -6.25, -3.65, 1.28, 0, 0, 0, 1, 3)]
  return data_logical_pose_table

def main_func():
  cnx = mysql.connector.connect(user='root', password="bitorobotics", 
    host="localhost", database="external_database")
  cursor = cnx.cursor()
  
  # clear tables
  cursor.execute("delete from logical_pose_table_3d")
  cnx.commit()

  add_logical_pose = ("INSERT INTO logical_pose_table_3d "
               "(logical_pose, real_pose_x, real_pose_y, \
                 real_pose_z, real_pose_qx, real_pose_qy, \
                 real_pose_qz, real_pose_qw, real_pose_id) "
               "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)")
  logical_poses = logical_pose_table_data()
  for lp in logical_poses:
    cursor.execute(add_logical_pose, lp)
  cnx.commit()

  cnx.close()
  return

if __name__ == "__main__":
  print " Program Begin ..."
  main_func()
  print " Program End ..."
