from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys

DB_NAME = 'external_database'


if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    cnx = mysql.connector.connect(host=server_ip, user='root', password='bitorobotics')
else:
    cnx = mysql.connector.connect(user='root', password='bitorobotics')

cursor = cnx.cursor()


TABLES2 = {}
TABLES2["task_table"] = (
    "CREATE TABLE `task_table` ("
    "  `id` bigint not null auto_increment,"
    "  `start` varchar(10) not null,"
    "  `goal` varchar(10) not null,"
    "  `start_action` smallint not null,"
    "  `goal_action` smallint not null,"
    "  `item_type` varchar(50) not null default '',"
    # "  `item_size_length` decimal(8, 4) not null default 0.0,"
    # "  `item_size_width` decimal(8, 4) not null default 0.0,"
    # "  `item_size_height` decimal(8, 4) not null default 0.0,"
    # "  `item_weight` decimal(8, 4) not null default 0.0,"
    "  `priority` int not null default 10,"
    "  `status` int not null default 0,"
    # "  `estimated_finish_timestamp` timestamp," # become useless
    "  `preassignment` varchar(25) not null default '',"
    "  `assignment` varchar(25) not null default '',"
    # from Qinghui Zhang
    "  `task_id` varchar(20) not null default '',"
    "  `create_time` datetime not null default CURRENT_TIMESTAMP,"
    "  `plan_time` datetime not null default '1000-01-01 00:00:00',"
    "  `actual_time` datetime not null default '1000-01-01 00:00:00',"
    "  `complete_time` datetime not null default '1000-01-01 00:00:00',"
    # "  `sync_status` int not null default 0,"
    "  `run_err_code` varchar(10) not null default '',"
    "  `run_err_msg` varchar(50) not null default '',"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )

try:
    cnx.database = DB_NAME
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
        # create_database(cursor)
        cnx.database = DB_NAME
    else:
        print(err)
        exit(1)

cursor.execute("drop table if exists task_table")
for name, ddl in TABLES2.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

cursor.close()
cnx.close()
