import sys 
import mysql.connector as mc
sys.setrecursionlimit(150000)

class NODE:
    count = 0
    def __init__(self, x, y, theta, cost = 0, types = 0):
        self.x = x
        self.y = y
        self.theta = theta%360
        NODE.count += 1
        self.id = NODE.count
        self.cost = cost
        self.type = types

    # for printing and debugging purposes
    def __repr__(self):
        return 'id: ' + str(self.id) + '\n'

################################################################################
# SETUP:
################################################################################

# motion primatives represent the change possible in a unit box as [dx, dy, dtheta] and are described as a function of their rotation 
# this is from a 4 connected differential drive robot
# motion_primatives = {90: [[0, 1, 0], [-1, 1, 90], [1, 1, -90], [0, 0, 90], [0, 0, -90]],
#                     0:   [[1, 0, 0], [1, 1, 90], [1, -1, -90], [0, 0, 90], [0, 0, -90]],
#                     180: [[-1, 0, 0], [-1, 1, -90], [-1, -1, 90], [0, 0, 90], [0, 0, -90]],
#                     270: [[0, -1, 0], [1, -1, 90], [-1, -1, -90], [0, 0, 90], [0, 0, -90]]}

# motion primatives represent the change possible in a unit box as [dx, dy, dtheta] and are described as a function of their rotation 
# this is from a 4 connected differential drive robot
motion_primatives = {90: [[0, 1, 0], [0, 0, 45], [0, 0, -45]],
                    0:   [[1, 0, 0], [0, 0, 45], [0, 0, -45]],
                    180: [[-1, 0, 0], [0, 0, 45], [0, 0, -45]],
                    270: [[0, -1, 0], [0, 0, 45], [0, 0, -45]],
                    45:  [[1, 1, 0], [0, 0, 45], [0, 0, -45]],
                    135: [[-1, 1, 0], [0, 0, 45], [0, 0, -45]],
                    225: [[-1, -1, 0], [0, 0, 45], [0, 0, -45]],
                    315: [[1, -1, 0], [0, 0, 45], [0, 0, -45]]}

# roadmap id number
num = 8

# starting node WARNING: MUST BE AN ALLOWABLE CONFIGURATION GIVEN THE BOUNDARY CONDITIONS
# (x, y, theta in degrees)
start = (0, 0, 90)

# boundary conditions for a rectangular grid
# for more control update the inBounds function
minX = 0
minY = 0
maxX = 10
maxY = 10

# number of nodes per unit x and y, can be a fraction number like 0.5
denX = 0.5
denY = 0.5

# connects to the appropriate SQL database
connection = mc.connect (host = "localhost", user = "root", passwd = "bitorobotics", db = "external_database")
cursor = connection.cursor()

################################################################################

def expand(node):
    # creates the list of nodes and edges that are possible given the motion primatives
    # and constraints on the boundary conditions

    def inBounds(node):
        # Checks whether or not the new position is on the map
        # unique to each map, changed to a unique 2d array of 1s and 0s
        return node.x <= maxX*denX and node.y <= maxY*denY and node.x >= minX*denX and node.y >= minY*denY 

    for motion in motion_primatives[node.theta]:
        temp = NODE(node.x + (motion[0]), node.y + (motion[1]), node.theta + motion[2])
        if (inBounds(temp)):
            if ((temp.x, temp.y, temp.theta) not in nodes):
                nodes[(temp.x, temp.y, temp.theta)] = temp
                edges[(temp.x, temp.y, temp.theta)] = set()
                expand(temp)
            else:
                NODE.count -= 1

            edges[(node.x, node.y, node.theta)].add(nodes[(temp.x, temp.y, temp.theta)])
        else: 
            NODE.count -= 1


def updateTables(nodes, edges, num):
    # clears the exhisting tables

    node_table = "roadmap_node_table_" + str(num)
    edge_table = "roadmap_edge_table_" + str(num)
    logic_table = "logical_pose_table_" + str(num)

    try: 
        sql_command = """drop table %s;""" %(node_table)
        cursor.execute(sql_command)
    except:
        pass

    sql_command = """
    CREATE TABLE %s ( 
    node_id BIGINT(20) NOT NULL PRIMARY KEY, 
    x DECIMAL(8,4) NOT NULL, 
    y DECIMAL(8,4) NOT NULL, 
    theta DECIMAL(8,4) NOT NULL, 
    cost DECIMAL(8,4) DEFAULT 0, 
    type SMALLINT(6) DEFAULT 0,
    status SMALLINT(6) DEFAULT 1);""" %(node_table)

    cursor.execute(sql_command)


    try:
        sql_command = """drop table %s;""" %(edge_table)
        cursor.execute(sql_command)
    except:
        pass

    sql_command = """
    CREATE TABLE %s ( 
    edge_id BIGINT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    source BIGINT(20) NOT NULL, 
    target BIGINT(20) NOT NULL,
    cost DECIMAL(8, 4) DEFAULT -1,
    type SMALLINT(6) DEFAULT 0);""" %(edge_table)

    cursor.execute(sql_command)

    try:
        sql_command = """drop table %s;""" %(logic_table)
        cursor.execute(sql_command)
    except:
        pass

    sql_command = """
    CREATE TABLE %s ( 
    id BIGINT(20) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    logical_pose VARCHAR(10) NOT NULL, 
    real_pose_x DECIMAL(10,4) NOT NULL,
    real_pose_y DECIMAL(10,4) NOT NULL,
    real_pose_theta DECIMAL(10,4) NOT NULL,
    real_pose_id BIGINT(20) NOT NULL,
    info VARCHAR(50) NOT NULL DEFAULT '',
    status INT(11) NOT NULL DEFAULT 0,
    region_code VARCHAR(10) NOT NULL DEFAULT '',
    start_action_type INT(11) NOT NULL DEFAULT 0,
    goal_action_type INT(11) NOT NULL DEFAULT 0);""" %(logic_table)

    cursor.execute(sql_command)

    # adds nodes and edges to specified tables
    for key in nodes:
        node = nodes[key]
        sql_command = """INSERT INTO %s VALUES (%s, %s, %s, %s, %s, %s, %s);""" %(node_table, node.id, node.x/float(denX), node.y/float(denY), node.theta*3.14159/180.0, node.cost, node.type, 1)
        cursor.execute(sql_command)
        sql_command = """INSERT INTO %s (logical_pose, real_pose_x, real_pose_y, real_pose_theta, real_pose_id) values (%s, '%s', %s, %s, %s);""" %(logic_table, node.id, node.x/float(denX), node.y/float(denY), node.theta*3.14159/180.0, node.id)
        cursor.execute(sql_command)

    
    for key in edges:
        edge = edges[key]
        for target in edge:
            sql_command = """INSERT INTO %s (source, target, cost) values (%s, %s, %s);""" %(edge_table, nodes[key].id, target.id, 1.0)
            cursor.execute(sql_command)


################################################################################
# RUNNING
################################################################################

x, y, theta = start
nodes = {start: NODE(x, y, theta)}
edges = {start: set()}

expand(nodes[start])
updateTables(nodes, edges, num)

# Commiting changes
connection.commit()
cursor.close()
connection.close()

################################################################################
