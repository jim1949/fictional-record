from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys

DB_NAME = 'external_database'
item_type_table_name = "item_type_table"
logical_pose_table_name = ""
logical_pose_table_3d_name = ""
roadmap_node_table_name = ""
roadmap_node_table_3d_name = ""
roadmap_edge_table_name = ""
robot_config_table_name = "robot_config_table"
robot_info_table_name = "robot_info_table"
region_table_name = "region_table"
storage_table_name = "storage_table"
user_table_name = "user_table"
error_code_table_name = "error_code_table"
action_table_name = "action_table"
# TODO: allow multiple task table

def create_database(cursor, table_seq_num, roadmap_seq_num):
    global logical_pose_table_name
    global roadmap_node_table_name
    global roadmap_edge_table_name
    global logical_pose_table_3d_name
    global roadmap_node_table_3d_name
    # logical_pose_table_name = "logical_pose_table_" + str(table_seq_num)
    # roadmap_node_table_name = "roadmap_node_table_" + str(roadmap_seq_num)
    # roadmap_edge_table_name = "roadmap_edge_table_" + str(roadmap_seq_num)
    logical_pose_table_name = "logical_pose_table"
    logical_pose_table_3d_name = "logical_pose_table_3d"
    roadmap_node_table_name = "roadmap_node_table"
    roadmap_node_table_3d_name = "roadmap_node_table_3d"
    roadmap_edge_table_name = "roadmap_edge_table"
    try:
        cursor.execute(
            "DROP DATABASE IF EXISTS {} ".format(DB_NAME))
    except mysql.connector.Error as err:
        print("Failed to drop database: {}".format(err))
    print("after drop")
    try:
        cursor.execute(
            "CREATE DATABASE {} DEFAULT CHARACTER SET 'utf8'".format(DB_NAME))
    except mysql.connector.Error as err:
        print("Failed creating database: {}".format(err))
        exit(1)


if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    cnx = mysql.connector.connect(host=server_ip, user='root', password='bitorobotics')
else:
    cnx = mysql.connector.connect(user='root', password='bitorobotics')

cursor = cnx.cursor()

create_database(cursor, 0, 0)

# logical pose table
TABLES = {}
TABLES[logical_pose_table_name] = (
    "CREATE TABLE `" + logical_pose_table_name + "` ("
    "  `id` bigint not null default 0,"
    "  `logical_pose` varchar(10) not null,"
    "  `real_pose_x` decimal(10, 4) not null,"
    "  `real_pose_y` decimal(10, 4) not null,"
    "  `real_pose_theta` decimal(10, 4) not null,"
    "  `real_pose_id` bigint not null,"
    "  `info` varchar(50) not null default '',"
    "  `status` int not null default 0,"
    "  `region_code` varchar(20) not null default '',"
    "  `start_action_type` int not null default 0,"
    "  `goal_action_type` int not null default 0,"
    "  PRIMARY KEY (`logical_pose`)"
    ") ENGINE=InnoDB"
    )

# logical pose table 3d
TABLES1 = {}
TABLES1[logical_pose_table_3d_name] = (
    "CREATE TABLE `" + logical_pose_table_3d_name + "` ("
    "  `id` bigint not null default 0,"
    "  `logical_pose` varchar(10) not null,"
    "  `real_pose_x` decimal(10, 4) not null,"
    "  `real_pose_y` decimal(10, 4) not null,"
    "  `real_pose_z` decimal(10, 4) not null,"
    "  `real_pose_qx` decimal(10, 4) not null,"
    "  `real_pose_qy` decimal(10, 4) not null,"
    "  `real_pose_qz` decimal(10, 4) not null,"
    "  `real_pose_qw` decimal(10, 4) not null,"
    "  `real_pose_id` bigint not null,"
    "  `info` varchar(50) not null default '',"
    "  `status` int not null default 0,"
    "  `region_code` varchar(20) not null default '',"
    "  `start_action_type` int not null default 0,"
    "  `goal_action_type` int not null default 0,"
    "  PRIMARY KEY (`logical_pose`)"
    ") ENGINE=InnoDB"
    )

# task table
TABLES2 = {}
TABLES2["task_table"] = (
    "CREATE TABLE `task_table` ("
    "  `id` bigint not null auto_increment,"
    "  `start` varchar(10) not null,"
    "  `goal` varchar(10) not null,"
    "  `start_action` smallint not null,"
    "  `goal_action` smallint not null,"
    "  `item_type` varchar(50) not null default '',"
    # "  `item_size_length` decimal(8, 4) not null default 0.0,"
    # "  `item_size_width` decimal(8, 4) not null default 0.0,"
    # "  `item_size_height` decimal(8, 4) not null default 0.0,"
    # "  `item_weight` decimal(8, 4) not null default 0.0,"
    "  `priority` int not null default 10,"
    "  `status` int not null default 0,"
    # "  `estimated_finish_timestamp` timestamp," # become useless
    "  `preassignment` varchar(25) not null default '',"
    "  `assignment` varchar(25) not null default '',"
    # from Qinghui Zhang
    "  `task_id` varchar(20) not null default '',"
    "  `create_time` datetime not null default CURRENT_TIMESTAMP,"
    "  `plan_time` datetime not null default '1000-01-01 00:00:00',"
    "  `actual_time` datetime not null default '1000-01-01 00:00:00',"
    "  `complete_time` datetime not null default '1000-01-01 00:00:00',"
    # "  `sync_status` int not null default 0,"
    "  `run_err_code` varchar(10) not null default '',"
    "  `run_err_msg` varchar(50) not null default '',"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )

# robot home table
TABLES3 = {}
TABLES3["home_pose_table"] = ( # serial is 22 char 
    "CREATE TABLE `home_pose_table` ("
    "  `serial` varchar(25) not null,"
    "  `home_pose_x` decimal(10, 4) not null,"
    "  `home_pose_y` decimal(10, 4) not null,"
    "  `home_pose_theta` decimal(10, 4) not null,"
    "  `home_pose_id` bigint not null,"
    "  PRIMARY KEY (`serial`)"
    ") ENGINE=InnoDB"
    )

# roadmap node table
TABLES4 = {}
TABLES4[roadmap_node_table_name] = (
    "CREATE TABLE `" + roadmap_node_table_name + "` ("
    "  `node_id` bigint not null,"
    "  `x` decimal(8,4) not null,"
    "  `y` decimal(8,4) not null,"
    "  `theta` decimal(8,4) not null,"
    "  `cost` decimal(8,4) default 0.0,"
    "  `type` smallint default 0,"
    "  `status` smallint DEFAULT 0,"
    "  PRIMARY KEY (`node_id`)"
    ") ENGINE=InnoDB"
    )

# roadmap node table 3d
TABLES4b = {}
TABLES4b[roadmap_node_table_3d_name] = (
    "CREATE TABLE `" + roadmap_node_table_3d_name + "` ("
    "  `node_id` bigint not null,"
    "  `x` decimal(8,4) not null,"
    "  `y` decimal(8,4) not null,"
    "  `z` decimal(8,4) not null,"
    "  `qx` decimal(8,4) not null,"
    "  `qy` decimal(8,4) not null,"
    "  `qz` decimal(8,4) not null,"
    "  `qw` decimal(8,4) not null,"
    "  `cost` decimal(8,4) default 0.0,"
    "  `type` smallint default 0,"
    "  `status` smallint DEFAULT 0,"
    "  PRIMARY KEY (`node_id`)"
    ") ENGINE=InnoDB"
    )


# TABLES4 = {}
# TABLES4[roadmap_node_table_name] = (
#     "CREATE TABLE `" + roadmap_node_table_name + "` ("
#     "  `vertexId` bigint not null,"
#     "  `vertexPoseX` decimal(8,4) not null,"
#     "  `vertexPoseY` decimal(8,4) not null,"
#     "  `vertexPoseA` decimal(8,4) not null,"
#     "  `vertexCost` decimal(8,4) default 0.0,"
#     "  `vertexType` smallint default 0,"
#     "  `vertexBlanketId` int default 0,"
#     "  `vertexStripId` int default 0,"
#     "  `vertexTagId` int default -1,"
#     "  `vertexIsLock` tinyint default -1,"
#     "  PRIMARY KEY (`vertexId`)"
#     ") ENGINE=InnoDB"
#     )

# roadmap edge table
TABLES5 = {}
TABLES5[roadmap_edge_table_name] = (
    "CREATE TABLE `" + roadmap_edge_table_name + "` ("
    "  `edge_id` bigint not null auto_increment,"
    "  `source` bigint not null,"
    "  `target` bigint not null,"
    "  `cost` decimal(8,4) not null default -1.0,"
    "  `type` smallint default 0,"
    "  PRIMARY KEY (`edge_id`)"
    ") ENGINE=InnoDB"
    )

# TABLES5 = {}
# TABLES5[roadmap_edge_table_name] = (
#     "CREATE TABLE `" + roadmap_edge_table_name + "` ("
#     "  `edgeId` bigint not null auto_increment,"
#     "  `edgeFrom` bigint not null,"
#     "  `edgeTo` bigint not null,"
#     "  `edgeCost` decimal(8,4) not null default -1.0,"
#     "  `edgeType` smallint default 0,"
#     "  PRIMARY KEY (`edgeId`)"
#     ") ENGINE=InnoDB"
#     )

# item type database
TABLES6 = {}
TABLES6[item_type_table_name] = (
    "CREATE TABLE `" + item_type_table_name + "` ("
    "  `id` bigint not null auto_increment,"
    "  `type` bigint not null default 0," # must be unique
    "  `name` varchar(25) not null,"
    "  `length` decimal(8, 4) not null default 0.0,"
    "  `width` decimal(8, 4) not null default 0.0,"
    "  `height` decimal(8, 4) not null default 0.0,"
    "  `weight` decimal(8, 4) not null default 0.0,"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )

# robot config table
TABLES7a = {}
TABLES7a[robot_config_table_name] = (
    "CREATE TABLE `" + robot_config_table_name + "` ("
    "  `id` bigint not null auto_increment,"
    "  `serial` varchar(25) not null,"
    "  `battery_voltage` decimal(8, 4) not null default 0.0,"
    "  `payload` decimal(8, 4) not null default 0.0,"
    "  `trajectory_mode` smallint not null default 0,"
    "  `footprint_c1_x` decimal(8, 4) not null default 0.0,"
    "  `footprint_c1_y` decimal(8, 4) not null default 0.0,"
    "  `footprint_c1_r` decimal(8, 4) not null default -1.0,"
    "  `footprint_c2_x` decimal(8, 4) not null default 0.0,"
    "  `footprint_c2_y` decimal(8, 4) not null default 0.0,"
    "  `footprint_c2_r` decimal(8, 4) not null default -1.0,"
    "  `footprint_c3_x` decimal(8, 4) not null default 0.0,"
    "  `footprint_c3_y` decimal(8, 4) not null default 0.0,"
    "  `footprint_c3_r` decimal(8, 4) not null default -1.0,"
    "  `footprint_c4_x` decimal(8, 4) not null default 0.0,"
    "  `footprint_c4_y` decimal(8, 4) not null default 0.0,"
    "  `footprint_c4_r` decimal(8, 4) not null default -1.0,"
    "  `footprint_c5_x` decimal(8, 4) not null default 0.0,"
    "  `footprint_c5_y` decimal(8, 4) not null default 0.0,"
    "  `footprint_c5_r` decimal(8, 4) not null default -1.0,"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )



# robot info database
TABLES7 = {}
TABLES7[robot_info_table_name] = (
    "CREATE TABLE `" + robot_info_table_name + "` ("
    "  `id` bigint not null auto_increment,"
    "  `serial` varchar(25) not null,"
    "  `status` smallint not null default 0,"
    "  `battery` smallint not null default -1,"
    "  `payload` decimal(8, 4) not null default 0.0,"
    # "  `task_id` bigint not null default -1,"
    "  `robot_pose_x` decimal(8, 4) not null default 0.0,"
    "  `robot_pose_y` decimal(8, 4) not null default 0.0,"
    "  `robot_pose_theta` decimal(8, 4) not null default 0.0,"
    # "  `robot_goal_x` decimal(8, 4) not null default 0.0,"
    # "  `robot_goal_y` decimal(8, 4) not null default 0.0,"
    # "  `robot_goal_theta` decimal(8, 4) not null default 0.0,"
    "  `run_err_code` varchar(10) not null default '',"
    "  `run_err_msg` varchar(50) not null default '',"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )

# TABLES8 = {}
# TABLES8[region_table_name] = (
#     "CREATE TABLE `" + region_table_name + "` ("
#     "  `id` bigint not null auto_increment,"
#     "  `code` varchar(10) not null default '',"
#     "  `name` varchar(50) not null default '',"
#     "  `info` varchar(100) not null default '',"
#     "  PRIMARY KEY (`id`)"
#     ") ENGINE=InnoDB"
#     )

# TABLES9 = {} # this table should not be part of BITO system
# TABLES9[storage_table_name] = (
#     "CREATE TABLE `" + storage_table_name + "` ("
#     "  `id` bigint not null auto_increment,"
#     "  `in_date` datetime not null,"
#     "  `order_code` varchar(20) not null default '',"
#     "  `group_name` varchar(20) not null default '',"
#     "  `client_name` varchar(50) not null default '',"
#     "  `batch` varchar(20) not null default '',"
#     "  `stack` varchar(10) not null default '',"
#     "  `materials` varchar(50) not null default '',"
#     "  `width` varchar(20) not null default '',"
#     "  `size_length` decimal(12,2) not null default 0.0,"
#     "  `size_width` decimal(12,2) not null default 0.0,"
#     "  `type` varchar(20) not null default '',"
#     "  `slices` varchar(20) not null default '',"
#     "  `profile` varchar(20) not null default '',"
#     "  `partial_pressure` varchar(20) not null default '',"
#     "  `note` varchar(100) not null default '',"
#     "  `task_id` varchar(20) not null default '',"
#     "  PRIMARY KEY (`id`)"
#     ") ENGINE=InnoDB"
#     )

TABLES10 = {}
TABLES10[user_table_name] = (
    "CREATE TABLE `" + user_table_name + "` ("
    "  `id` bigint not null auto_increment,"
    "  `code` varchar(10) not null default '',"
    "  `name` varchar(50) not null default '',"
    "  `pass` varchar(50) not null default '',"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )

TABLES11 = {}
TABLES11[error_code_table_name] = (
    "CREATE TABLE `" + error_code_table_name + "` ("
    "  `id` bigint not null auto_increment,"
    "  `dtc_code` bigint not null,"
    # "  `dtc_name` varchar(10) not null,"
    "  `owner` varchar(50) not null default '',"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )


# action table, mainly for actions that start and end at different nodes
TABLES12 = {}
TABLES12[action_table_name] = (
    "CREATE TABLE `" + action_table_name + "` ("
    "  `id` bigint not null,"
    "  `name` varchar(25) not null,"
    "  `level` smallint not null default 0,"
    "  `start_logical_pose` varchar(10) not null,"
    "  `end_logical_pose` varchar(10) not null,"
    "  `trajectory_point_1_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_1_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_1_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_2_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_2_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_2_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_3_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_3_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_3_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_4_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_4_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_4_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_5_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_5_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_5_theta` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_6_x` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_6_y` decimal(8, 4) not null default 0.0,"
    "  `trajectory_point_6_theta` decimal(8, 4) not null default 0.0,"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )

try:
    cnx.database = DB_NAME
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
        create_database(cursor)
        cnx.database = DB_NAME
    else:
        print(err)
        exit(1)

# for name, ddl in TABLES.iteritems():
#     try:
#         print("Creating table {}: ".format(name), end='')
#         cursor.execute(ddl)
#     except mysql.connector.Error as err:
#         if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
#             print("already exists.")
#         else:
#             print(err.msg)
#     else:
#         print("OK")

for name, ddl in TABLES1.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

for name, ddl in TABLES2.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

for name, ddl in TABLES3.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

for name, ddl in TABLES4.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

for name, ddl in TABLES4b.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

for name, ddl in TABLES5.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")


for name, ddl in TABLES6.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")


for name, ddl in TABLES7a.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

for name, ddl in TABLES7.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")


# for name, ddl in TABLES8.iteritems():
#     try:
#         print("Creating table {}: ".format(name), end='')
#         cursor.execute(ddl)
#     except mysql.connector.Error as err:
#         if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
#             print("already exists.")
#         else:
#             print(err.msg)
#     else:
#         print("OK")


# for name, ddl in TABLES9.iteritems():
#     try:
#         print("Creating table {}: ".format(name), end='')
#         cursor.execute(ddl)
#     except mysql.connector.Error as err:
#         if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
#             print("already exists.")
#         else:
#             print(err.msg)
#     else:
#         print("OK")

for name, ddl in TABLES10.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

for name, ddl in TABLES11.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

for name, ddl in TABLES12.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

cursor.close()
cnx.close()
