'''
 * All Rights Reserved
 * BITO Robotics, Inc.
 *
 * Authors: Puneet Singhal, 
 * Create Date: 2018-06
 * Last Edit Date: 2018-06
'''

# Import Python libraries
import time
import sys

# Import SQL related libraries
import mysql.connector
from mysql.connector import errorcode


DB_NAME = 'external_database'

def getTime():
	localtime 	= time.localtime()
	return str(localtime[0]) + '-' + str(localtime[1]) + '-' + \
			str(localtime[2]) + ' ' + str(localtime[3]) + ':' + \
			str(localtime[4]) + ':' + str(localtime[5]) 

if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    config = {'host':server_ip, 'user':'root', \
    			'password':'bitorobotics', 'database':DB_NAME}
else:
	config = {'user':'root', 'password':'bitorobotics', \
				'database':DB_NAME}

try:
    cnx = mysql.connector.connect(**config)
except mysql.connector.Error as err:
	if err.errno == errorcode.ER_BAD_DB_ERROR:
		print("Database {} does not exist". format(DB_NAME))
	else:
		print(err)

cursor = cnx.cursor()

query = ("INSERT INTO task_table " +
		"(start, goal, start_action, goal_action, " +
		"estimated_finish_timestamp, preassignment) " +
		"VALUES (%s, %s, %s, %s, %s, %s)")

start 						= 'H3_4'
goal 						= 'H2_1'
start_action 				= 0
goal_action 				= 0
estimated_finish_timestamp 	= getTime()
preassignment				= 'yg00a00017120415001n00'

data = (start, goal, start_action, goal_action, \
			estimated_finish_timestamp, preassignment)

cursor.execute(query, data)

# Make sure data is committed to the database
cnx.commit()

cursor.close()
cnx.close()


