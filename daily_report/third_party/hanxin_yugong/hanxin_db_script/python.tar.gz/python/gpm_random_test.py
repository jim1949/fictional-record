#!/usr/bin/env python
'''
 * All Rights Reserved
 * BITO Robotics, Inc.
 *
 * Authors: Xiaokun Jiang,
 * Create Date: 2019-11
 * Last Edit Date: 2019-11
'''
from __future__ import print_function

import time
import sys
import yaml
import random
from os.path import expanduser

# Import SQL related libraries
import mysql.connector
from mysql.connector import errorcode

DB_NAME = 'external_database'
PURE_UP = 7
PURE_DOWN = 8
TEST_TASK_NUM = 50

def insert_task(start, goal, cursor, table_name = "task_table"):
    query = ("INSERT INTO " + table_name + 
    " (start, goal, start_action, goal_action, " + 
    "priority, preassignment) " +
    "VALUES (%s, %s, %s, %s, %s, %s) ")
    start_action 		       = PURE_UP
    goal_action 			   = PURE_DOWN
    priority                   = 10
    preassignment			   = ''
    data = (start, goal, start_action, goal_action, priority, preassignment)
    cursor.execute(query, data)
    return

def load_action_tag_config():
    home = expanduser("~")
    with open(home+"/hanxin_ws/src/hanxin/hanxin/param/gpm_action_tag.yaml",'r') as yaml_file:
        config_dict = yaml.load(yaml_file)
    middle_tag_num = config_dict['/node_factory_server_2d/middle_tag_num']
    action_tag_nodeset = config_dict['/node_factory_server_2d/all_logical_action_tag']
    rack_point_set = []
    for i in range(0, len(action_tag_nodeset),2+middle_tag_num):
        rack_point_set.append(action_tag_nodeset[i])
    return rack_point_set

def truncate_task_table(cursor, table_name = "task_table"):
    cursor.execute("TRUNCATE TABLE " + table_name)
    print("task table truncated")

def main_func():
    #
    server_ip = "localhost"
    try:
        dbc = mysql.connector.connect(host=server_ip, user='root', password='bitorobotics')
    except mysql.connector.Error as err:
	    if err.errno == errorcode.ER_BAD_DB_ERROR:
		    print("Database {} does not exist". format(DB_NAME))
	    else:
		    print(err)
    dbc.database = DB_NAME
    print("database connected")
    task_table = "task_table"
    
    # clean up task table
    cursor= dbc.cursor()

    print("please input cmd type:")
    print("0: insert new tasks, and do not truncate task table")
    print("1: insert new tasks, and TRUNCATE task table")
    print("2: ONLY TRUNCATE task table")
    user_input = raw_input()
    if user_input == '1' or user_input == '2':
        print("WARN Would you want to clean your task table of hanxin? y/n ")
        make_sure = raw_input()
        while True:
            if make_sure.lower() == 'y' or make_sure.lower() == 'n':
                break
            make_sure = raw_input("error: wrong input. Please put y or n only ")
        if make_sure.lower == 'n':
            return
    if user_input not in ['0','1','2']:
        print("error: wrong cmd, exit")
        return
    # connect external db

    if user_input == '1' or user_input == '2':
        truncate_task_table(cursor, task_table)
    if user_input == '2':
        return 
    
    # load action_tag cofig
    target_set = load_action_tag_config()
 
    # get random start and goal
    for i in range(TEST_TASK_NUM):
      r_start_idx = random.randint(0, len(target_set)-1)
      r_goal_idx = random.randint(0, len(target_set)-1)
      start = target_set[r_start_idx]
      goal = target_set[r_goal_idx]
      # insert task
      insert_task(start,goal, cursor, task_table)
    dbc.commit()
    print("finished to insert random tasks")

    # close the db connection
    cursor.close()
    dbc.close()


if __name__ == "__main__":
    print("Insert Random GPM Test Task Program Begin ...")
    print()
    main_func()
    print()
    print("Insert Random GPM Test Task Program End ...")