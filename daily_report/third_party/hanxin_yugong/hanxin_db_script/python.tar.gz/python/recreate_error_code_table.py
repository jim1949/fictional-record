from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys

DB_NAME = 'external_database'


error_code_table_name = "error_code_table"


if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    cnx = mysql.connector.connect(host=server_ip, user='root', password='bitorobotics')
else:
    cnx = mysql.connector.connect(user='root', password='bitorobotics')

cursor = cnx.cursor()


TABLES11 = {}
TABLES11[error_code_table_name] = (
    "CREATE TABLE `" + error_code_table_name + "` ("
    "  `id` bigint not null auto_increment,"
    "  `dtc_code` bigint not null,"
    # "  `dtc_name` varchar(10) not null,"
    "  `owner` varchar(50) not null default '',"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )



try:
    cnx.database = DB_NAME
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
        # create_database(cursor)
        cnx.database = DB_NAME
    else:
        print(err)
        exit(1)

cursor.execute("drop table if exists "+error_code_table_name)

for name, ddl in TABLES11.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

cursor.close()
cnx.close()
