import MySQLdb

class node_IO_Database_Py:
	def __init__(self, \
		in_host = "localhost", \
		in_user = "root", \
		in_passwd = "bitorobotics", \
		in_db = "external_database"):
		self.db = MySQLdb.connect(host = in_host, user = in_user, passwd = in_passwd, db = in_db)
		self.cur = self.db.cursor()
	def io_database_download(self, tableName):
		retval = 0
		retval = self.cur.execute("SELECT * from " + tableName + ";")
		rows = self.cur.fetchall()
		return retval, rows
	def io_database_downloadselect(self,condition, tableName):
		retval = 0
		retval = self.cur.execute("SELECT * from " + tableName + " where "+condition+";")
		rows = self.cur.fetchall()
		return retval, rows
	def io_database_get_schema(self, tableName):
		retval = 0
		retval = self.cur.execute("describe " + tableName + ";")
		rows = self.cur.fetchall()
		return retval, rows
	def io_database_del_all(self, tableName):
		retval = 0
		retval = self.cur.execute("TRUNCATE TABLE " + tableName);
		rows = self.cur.fetchall()
		self.db.commit()
		return retval

	def io_database_del(self,id, tableName):
		retval = 0
		retval = self.cur.execute("DELETE from " + tableName + " where id = "+"'"+str(id)+"'"+";")
		rows = self.cur.fetchall()
		self.db.commit()
		return retval

	def io_database_dup_table_node(self, tableName):
		retval = 0
		retval = self.cur.execute("DROP TABLE roadmap_node_table;")
		retval = self.cur.execute("CREATE TABLE roadmap_node_table LIKE " + tableName + ";")
		retval = self.cur.execute("INSERT roadmap_node_table SELECT * FROM " + tableName + ";")
		retval = self.cur.execute("SELECT * FROM roadmap_node_table;")
		rows = self.cur.fetchall()
		self.db.commit()
		print("change committed")
		return "done"

	def io_database_dup_table_edge(self, tableName):
		retval = 0
		retval = self.cur.execute("DROP TABLE roadmap_edge_table;")
		retval = self.cur.execute("CREATE TABLE roadmap_edge_table LIKE " + tableName + ";")
		retval = self.cur.execute("INSERT roadmap_edge_table SELECT * FROM " + tableName + ";")
		retval = self.cur.execute("SELECT * FROM roadmap_edge_table;")
		rows = self.cur.fetchall()
		self.db.commit()
		print("change committed")
		return "done"
	# def io_database_update_taskobjects(self, task):
	# 	stat = "UPDATE taskObjects SET nodeId = "+str(task[1])+",taskTypeId= "+str(task[2])+",itemTypeId= "+str(task[3])+",itemNum= "+str(task[4])+",assignedRobot= \""+str(task[5])+"\",priority= "+str(task[6])+",aborted= "+str(task[7])+" where id = "+str(task[0]);
	# 	retval = self.cur.execute(stat)
	# 	self.db.commit()
	# 	return retval

	####NOTICE: upload id, start, goal, start_action, goal_action only here.
	def io_database_upload_node(self, node, tableName):
		stat = "INSERT into " + tableName + "(node_id,x,y,theta,cost,type,status) "\
		+"values ("+str(node[0])+","+str(node[1])+","+str(node[2])+","+str(node[3])+","+str(node[4])+"," + str(node[5])+",1)";
		print stat
		retval = self.cur.execute(stat)
		self.db.commit()
		return retval

	def io_database_upload_edge(self, node, tableName):
		stat = "INSERT into " + tableName + "(source, target, cost, type) "\
		+"values ("+str(node[0])+","+str(node[1])+","+str(node[2])+","+str(node[3])+")";
		print stat
		retval = self.cur.execute(stat)
		self.db.commit()
		return retval

	def io_database_get_roadmap_name(self):
		retval = 0
		retval = self.cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='external_database';")
		tables = self.cur.fetchall()
		return list(sum(tables, ()))

	def io_database_drop_table(self, tableName):
		retval = 0
		stat = "DROP TABLE " + tableName + ";"
		retval = self.cur.execute(stat)
		self.db.commit()
		return retval

	def io_database_create_new_node_table(self, tableName):
		retval = 0
		retval = self.cur.execute("CREATE TABLE " + tableName + "(node_id bigint not null, \
			x decimal(8,4) not null, y decimal(8,4) not null, theta decimal(8,4) not null, \
			cost decimal(8,4) default 0.0, type smallint default 0, status smallint default 1, PRIMARY KEY(node_id))")
		self.db.commit()
		return retval

	def io_database_create_new_edge_table(self, tableName):
		retval = 0
		retval = self.cur.execute("CREATE TABLE " + tableName + "(edge_id bigint not null auto_increment, \
			source bigint not null, target bigint not null, cost decimal(8,4) default -1.0, \
			type smallint default 0, PRIMARY KEY(edge_id))")
		self.db.commit()
		return retval

	def close(self):
		self.db.close()
if __name__ == "__main__":
	# dbw = node_IO_Database_Py("192.168.181.188", "root", "bitorobotics", "external_database")
	# (numRows, rows) = dbw.io_database_download_taskobjects_select("id>3")
	# print rows
	# (numRows, rows) = dbw.io_database_get_schema("taskObjects")

	###############################
	#### Node downloading part ####
	###############################
	from_node_table_name = "roadmap_node_table_6"
	to_node_table_name = "roadmap_node_table_7"

	dbw = node_IO_Database_Py("localhost", "root", "bitorobotics", "external_database")
	nodes = dbw.io_database_download(from_node_table_name)

	################################
	#### Edges downloading part ####
	################################
	from_edge_table_name = "roadmap_edge_table_6"
	to_edge_table_name = "roadmap_edge_table_7"

	edges = dbw.io_database_download(from_edge_table_name)


	###############################
	####  Wait for key  ####
	###############################

	raw_input("Download finished, Press Enter to continue upload...")

	###############################
	####  Node uploading part  ####
	###############################
	dbw.io_database_drop_table(to_node_table_name) # if table already exist, comment this line
	dbw.io_database_create_new_node_table(to_node_table_name)
	for idx in range(nodes[0]):
		dbw.io_database_upload_node(nodes[1][idx], to_node_table_name)

	################################
	####  Edges uploading part  ####
	################################
	dbw.io_database_drop_table(to_edge_table_name) # if table already exist, comment this line
	dbw.io_database_create_new_edge_table(to_edge_table_name)
	for idx in range(edges[0]):
		dbw.io_database_upload_edge(edges[1][idx], to_edge_table_name)


	# dbw.io_database_upload_node(['0','0','0','0','0','0'])
	dbw.close()
