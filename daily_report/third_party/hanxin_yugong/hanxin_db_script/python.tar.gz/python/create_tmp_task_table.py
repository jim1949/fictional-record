from __future__ import print_function

import mysql.connector
from mysql.connector import errorcode
import sys

DB_NAME = 'external_database'
item_type_table_name = "item_type_table"
logical_pose_table_name = ""
roadmap_node_table_name = ""
roadmap_edge_table_name = ""
robot_info_table_name = "robot_info_table"
region_table_name = "region_table"
storage_table_name = "storage_table"
user_table_name = "user_table"
error_code_table_name = "error_code_table"
# TODO: allow multiple task table

def create_database(cursor, table_seq_num, roadmap_seq_num):
    global logical_pose_table_name
    global roadmap_node_table_name
    global roadmap_edge_table_name
    # logical_pose_table_name = "logical_pose_table_" + str(table_seq_num)
    # roadmap_node_table_name = "roadmap_node_table_" + str(roadmap_seq_num)
    # roadmap_edge_table_name = "roadmap_edge_table_" + str(roadmap_seq_num)
    logical_pose_table_name = "logical_pose_table"
    roadmap_node_table_name = "roadmap_node_table"
    roadmap_edge_table_name = "roadmap_edge_table"
    try:
        cursor.execute(
            "DROP DATABASE IF EXISTS {} ".format(DB_NAME))
    except mysql.connector.Error as err:
        print("Failed to drop database: {}".format(err))
    print("after drop")
    try:
        cursor.execute(
            "CREATE DATABASE {} DEFAULT CHARACTER SET 'utf8'".format(DB_NAME))
    except mysql.connector.Error as err:
        print("Failed creating database: {}".format(err))
        exit(1)


if len(sys.argv) == 2:
    server_ip = sys.argv[1]
    cnx = mysql.connector.connect(host=server_ip, user='root', password='bitorobotics')
else:
    cnx = mysql.connector.connect(user='root', password='bitorobotics')

cursor = cnx.cursor()

# create_database(cursor, 0, 0)

# logical pose table
TABLES = {}
TABLES[logical_pose_table_name] = (
    "CREATE TABLE `" + logical_pose_table_name + "` ("
    "  `id` bigint not null default 0,"
    "  `logical_pose` varchar(10) not null,"
    "  `real_pose_x` decimal(10, 4) not null,"
    "  `real_pose_y` decimal(10, 4) not null,"
    "  `real_pose_theta` decimal(10, 4) not null,"
    "  `real_pose_id` bigint not null,"
    "  `info` varchar(50) not null default '',"
    "  `status` int not null default 0,"
    "  `region_code` varchar(10) not null default '',"
    "  `start_action_type` int not null default 0,"
    "  `goal_action_type` int not null default 0,"
    "  PRIMARY KEY (`logical_pose`)"
    ") ENGINE=InnoDB"
    )

# task table
TABLES2 = {}
TABLES2["task_table"] = (
    "CREATE TABLE `task_table` ("
    "  `id` bigint not null auto_increment,"
    "  `start` varchar(10) not null,"
    "  `goal` varchar(10) not null,"
    "  `start_action` smallint not null,"
    "  `goal_action` smallint not null,"
    "  `item_type` bigint not null default 0,"
    "  `item_size_length` decimal(8, 4) not null default 0.0,"
    "  `item_size_width` decimal(8, 4) not null default 0.0,"
    "  `item_size_height` decimal(8, 4) not null default 0.0,"
    "  `item_weight` decimal(8, 4) not null default 0.0,"
    "  `priority` int not null default 0,"
    "  `status` int not null default 0,"
    "  `estimated_finish_timestamp` timestamp," # become useless
    "  `preassignment` varchar(25) not null default '',"
    "  `assignment` varchar(25) not null default '',"
    # from Qinghui Zhang
    "  `task_id` varchar(20) not null default '',"
    "  `plan_time` datetime not null default '1000-01-01 00:00:00',"
    "  `actual_time` datetime not null default '1000-01-01 00:00:00',"
    "  `complete_time` datetime not null default '1000-01-01 00:00:00',"
    "  `sync_status` int not null default 0,"
    "  `run_err_code` varchar(10) not null default '',"
    "  `run_err_msg` varchar(50) not null default '',"
    "  PRIMARY KEY (`id`)"
    ") ENGINE=InnoDB"
    )

try:
    cnx.database = DB_NAME
except mysql.connector.Error as err:
    if err.errno == errorcode.ER_BAD_DB_ERROR:
        create_database(cursor)
        cnx.database = DB_NAME
    else:
        print(err)
        exit(1)

for name, ddl in TABLES2.iteritems():
    try:
        print("Creating table {}: ".format(name), end='')
        cursor.execute(ddl)
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
            print("already exists.")
        else:
            print(err.msg)
    else:
        print("OK")

cursor.close()
cnx.close()

